# Mini SIEM - Security Information and Event Management System

A comprehensive, educational SIEM system built with Python Flask that demonstrates real-world security monitoring capabilities in a fun, interactive way.

## 🚀 Features

### Core Security Monitoring
- **Log Upload & Processing**: Support for CSV and JSON log formats
- **Rule-Based Detection**: Automated detection of suspicious activities
- **Alert Generation**: Real-time alert creation with severity levels
- **Web Dashboard**: Interactive dashboard with charts and filtering
- **SQLite Database**: Persistent storage for logs and alerts

### Detection Rules
- **USB Data Exfiltration**: Detects large data transfers to USB devices (>100MB)
- **VPN Data Exfiltration**: Monitors unusual data transfers over VPN (>500MB)
- **Multiple Failed Logins**: Identifies brute force attempts (3+ consecutive failures)
- **Unusual Behavior**: Flags activity outside normal business hours
- **Custom Rules**: Admin-configurable detection patterns

### Educational & Fun Features
- **Find the Intruder Game**: Interactive security awareness game
- **Simulation Mode**: Generate and test with simulated security scenarios
- **Performance Analytics**: Visual charts and detection metrics
- **Learning Resources**: Built-in security education content

## 🛠️ Tech Stack

- **Backend**: Python Flask
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Charts**: Chart.js
- **Database**: SQLite
- **Icons**: Font Awesome
- **Deployment**: Ready for Render.com

## 📋 Prerequisites

- Python 3.7+
- pip (Python package manager)

## 🚀 Quick Start

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd mini-siem
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**
   ```bash
   python run.py
   ```

4. **Access the application**
   Open your browser and navigate to `http://localhost:5000`

## 📁 Project Structure

```
mini-siem/
├── app.py              # Main Flask application
├── run.py              # Application launcher
├── requirements.txt    # Python dependencies
├── siem.db             # SQLite database (created on first run)
├── uploads/            # Uploaded log files directory
├── templates/          # HTML templates
│   ├── base.html       # Base template with navigation
│   ├── index.html      # Home page
│   ├── dashboard.html  # Main dashboard
│   ├── upload.html     # Log upload interface
│   ├── game.html       # Find the Intruder game
│   └── simulation.html # Simulation mode
└── sample_logs/        # Sample log files
    ├── sample_logs.csv
    └── sample_logs.json
```

## 🎮 How to Use

### 1. Upload Security Logs
- Navigate to "Upload Logs" page
- Upload CSV or JSON log files
- Supported columns: timestamp, user, action, details, source

### 2. Monitor Dashboard
- View real-time alerts and statistics
- Filter alerts by severity and type
- Analyze user behavior patterns
- Export reports for compliance

### 3. Play "Find the Intruder"
- Test your security awareness
- Identify suspicious log entries
- Earn points and learn security concepts

### 4. Use Simulation Mode
- Generate simulated security scenarios
- Test detection rule effectiveness
- Learn about different attack patterns

## 🔧 Configuration

### Log File Format

**CSV Format:**
```csv
timestamp,user,action,details,source
2024-01-15 10:30:00,user1,file_copy,Copied 500MB to USB,USB-001
2024-01-15 10:35:00,user2,vpn_transfer,Transferred 2GB data,VPN-Server-1
```

**JSON Format:**
```json
[
  {
    "timestamp": "2024-01-15T10:30:00Z",
    "user": "user1",
    "action": "file_copy",
    "details": "Copied 500MB to USB device",
    "source": "USB-001"
  }
]
```

### Custom Detection Rules

Add custom rules in the database:
```sql
INSERT INTO rules (name, description, condition, severity)
VALUES ('Custom Rule', 'Description', 'keyword1 and keyword2', 'medium');
```

## 📊 Sample Data

The application includes sample log files demonstrating various security scenarios:

- **Normal Activities**: Regular user logins, file access, email sending
- **Suspicious Activities**: USB data exfiltration, VPN transfers, failed logins
- **Unusual Behavior**: After-hours activity, mass file operations

## 🔒 Security Features

- **Input Validation**: Secure file upload handling
- **SQL Injection Protection**: Parameterized queries
- **CSRF Protection**: Flask-WTF integration ready
- **Session Management**: Secure user sessions

## 🚢 Deployment

### Render.com Deployment

1. **Create a Render account** at [render.com](https://render.com)

2. **Connect your GitHub repository**

3. **Create a new Web Service**
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python run.py`

4. **Environment Variables** (if needed)
   - No additional environment variables required for basic functionality

5. **Deploy**
   - Render will automatically build and deploy your application

## 🎯 Learning Objectives

This project teaches:

- **SIEM Fundamentals**: Understanding security monitoring concepts
- **Log Analysis**: Processing and analyzing security logs
- **Detection Engineering**: Creating effective detection rules
- **Security Awareness**: Recognizing common attack patterns
- **Python Web Development**: Building full-stack applications
- **Database Design**: Working with SQLite for data persistence

## 🔄 Future Enhancements

- **Machine Learning Integration**: Anomaly detection using ML algorithms
- **Real-time Processing**: WebSocket-based live log streaming
- **Multi-tenancy**: Support for multiple organizations
- **Advanced Analytics**: More sophisticated threat hunting
- **API Integration**: RESTful APIs for external system integration
- **Mobile App**: React Native mobile application

## 🐛 Troubleshooting

### Common Issues

1. **Flask ImportError**: Ensure Flask is installed with `pip install flask`
2. **Database Issues**: Delete `siem.db` and restart the application
3. **File Upload Errors**: Check file permissions in the `uploads/` directory
4. **Chart Loading Issues**: Ensure internet connection for CDN resources

### Debug Mode

Run with debug logging:
```bash
python run.py --debug
```

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues and enhancement requests.

## 📞 Support

For support and questions:
- Create an issue in the GitHub repository
- Check the troubleshooting section above
- Review the code comments for implementation details

---

**Built with ❤️ for cybersecurity education and awareness**
