import sqlite3
import json
from datetime import datetime, timedelta
import os
import re
import csv
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from werkzeug.utils import secure_filename
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv', 'json'}
DATABASE = 'siem.db'

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Create upload folder if it doesn't exist
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Context processor for datetime
@app.context_processor
def inject_now():
    return {'datetime': datetime}

# Initialize database
def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Create alerts table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            user TEXT NOT NULL,
            details TEXT NOT NULL,
            severity TEXT DEFAULT 'medium',
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )
    ''')

    # Create logs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME,
            user TEXT,
            action TEXT,
            details TEXT,
            source TEXT
        )
    ''')

    # Create rules table for custom rules
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            condition TEXT NOT NULL,
            severity TEXT DEFAULT 'medium',
            enabled BOOLEAN DEFAULT 1
        )
    ''')

    # Insert default custom rules
    cursor.execute('SELECT COUNT(*) FROM rules')
    if cursor.fetchone()[0] == 0:
        cursor.execute('''
            INSERT INTO rules (name, description, condition, severity)
            VALUES
            ('Sensitive File Access', 'Alert when users access confidential or sensitive files', 'confidential and sensitive', 'high'),
            ('Night Shift Activity', 'Alert for any activity between 10 PM and 6 AM', 'night and activity', 'medium'),
            ('Mass File Operations', 'Alert when users perform bulk file operations', 'bulk and copy', 'medium'),
            ('Remote Access Pattern', 'Alert for unusual remote access patterns', 'remote and unusual', 'low')
        ''')

    conn.commit()
    conn.close()

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# API Endpoints for Dashboard
@app.route('/api/alerts')
def get_alerts():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT * FROM alerts
        ORDER BY timestamp DESC
        LIMIT 100
    ''')

    alerts = cursor.fetchall()
    conn.close()

    return jsonify([{
        'id': alert[0],
        'type': alert[1],
        'user': alert[2],
        'details': alert[3],
        'severity': alert[4],
        'timestamp': alert[5],
        'status': alert[6]
    } for alert in alerts])

@app.route('/api/risky-users')
def get_risky_users():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Get users with their alert counts and risk levels
    cursor.execute('''
        SELECT user, COUNT(*) as alert_count,
               MAX(severity) as max_severity,
               SUM(CASE WHEN details LIKE '%MB%' OR details LIKE '%GB%'
                   THEN CAST(REPLACE(REPLACE(details, 'MB', ''), 'GB', '') AS FLOAT) * 1000000
                   ELSE 0 END) as data_transferred
        FROM alerts
        GROUP BY user
        ORDER BY alert_count DESC
        LIMIT 10
    ''')

    users = cursor.fetchall()
    conn.close()

    # Map severity to risk level
    def get_risk_level(severity, alert_count):
        if severity == 'high' or alert_count >= 5:
            return 'high'
        elif severity == 'medium' or alert_count >= 3:
            return 'medium'
        else:
            return 'low'

    return jsonify([{
        'user': user[0],
        'alertCount': user[1],
        'riskLevel': get_risk_level(user[2], user[1]),
        'dataTransferred': user[3] or 0
    } for user in users])

@app.route('/api/logs')
def get_logs():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT * FROM logs
        ORDER BY timestamp DESC
        LIMIT 50
    ''')

    logs = cursor.fetchall()
    conn.close()

    return jsonify([{
        'id': log[0],
        'timestamp': log[1],
        'user': log[2],
        'action': log[3],
        'details': log[4],
        'source': log[5]
    } for log in logs])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/game')
def game():
    return render_template('game.html')

@app.route('/api/game-logs')
def get_game_logs():
    """Generate game logs with one suspicious entry"""
    # Sample normal log entries
    normal_logs = [
        {"timestamp": "2024-01-15 09:15:00", "user": "alice", "action": "login", "details": "Successful login from office"},
        {"timestamp": "2024-01-15 09:30:00", "user": "bob", "action": "file_access", "details": "Accessed project documents"},
        {"timestamp": "2024-01-15 10:00:00", "user": "charlie", "action": "email_send", "details": "Sent report to manager"},
        {"timestamp": "2024-01-15 11:15:00", "user": "alice", "action": "file_download", "details": "Downloaded presentation file"},
        {"timestamp": "2024-01-15 12:00:00", "user": "bob", "action": "vpn_connect", "details": "Connected to company VPN"},
        {"timestamp": "2024-01-15 14:30:00", "user": "charlie", "action": "meeting_join", "details": "Joined team meeting"},
        {"timestamp": "2024-01-15 15:45:00", "user": "alice", "action": "file_upload", "details": "Uploaded updated document"},
        {"timestamp": "2024-01-15 16:20:00", "user": "bob", "action": "logout", "details": "Logged out normally"}
    ]

    # Sample suspicious log entries
    suspicious_logs = [
        {"timestamp": "2024-01-15 23:30:00", "user": "eve", "action": "file_copy", "details": "Copied 2GB of data to USB at night"},
        {"timestamp": "2024-01-15 02:15:00", "user": "mallory", "action": "unauthorized_access", "details": "Attempted access to restricted files"},
        {"timestamp": "2024-01-15 18:45:00", "user": "trudy", "action": "mass_download", "details": "Downloaded 50 files rapidly"},
        {"timestamp": "2024-01-15 01:00:00", "user": "eve", "action": "vpn_tunnel", "details": "Unusual VPN connection at 1 AM"},
        {"timestamp": "2024-01-15 22:00:00", "user": "mallory", "action": "failed_logins", "details": "15 consecutive failed login attempts"}
    ]

    # Select random logs for the game
    import random
    selected_normal = random.sample(normal_logs, 4)
    selected_suspicious = random.sample(suspicious_logs, 1)

    game_logs = selected_normal + selected_suspicious
    random.shuffle(game_logs)

    # Mark the correct answer (index of suspicious log)
    correct_answer = game_logs.index(selected_suspicious[0])

    return jsonify({
        'logs': game_logs,
        'correct_answer': correct_answer,
        'question': 'Which log entry shows suspicious activity?'
    })

@app.route('/api/check-answer', methods=['POST'])
def check_answer():
    """Check if the user's answer is correct"""
    data = request.get_json()
    user_answer = data.get('answer')
    correct_answer = data.get('correct_answer')

    is_correct = user_answer == correct_answer

    # Update score in session
    if 'game_score' not in session:
        session['game_score'] = 0

    if is_correct:
        session['game_score'] += 10
        message = "Correct! You found the intruder!"
    else:
        message = "Wrong! That was a normal activity."

    return jsonify({
        'correct': is_correct,
        'message': message,
        'score': session['game_score']
    })

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/simulation')
def simulation():
    return render_template('simulation.html')

@app.route('/api/simulate-logs', methods=['POST'])
def simulate_logs():
    """Generate simulated logs based on user parameters"""
    data = request.get_json()
    scenario = data.get('scenario', 'mixed')
    count = min(int(data.get('count', 10)), 50)  # Limit to 50 logs

    simulated_logs = generate_simulated_logs(scenario, count)

    return jsonify({
        'logs': simulated_logs,
        'expected_alerts': count_detected_alerts(simulated_logs)
    })

def generate_simulated_logs(scenario, count):
    """Generate simulated logs for different scenarios"""
    import random

    base_logs = [
        {"timestamp": "2024-01-15 09:15:00", "user": "alice", "action": "login", "details": "Successful login from office", "source": "Local"},
        {"timestamp": "2024-01-15 09:30:00", "user": "bob", "action": "file_access", "details": "Accessed project documents", "source": "Network"},
        {"timestamp": "2024-01-15 10:00:00", "user": "charlie", "action": "email_send", "details": "Sent report to manager", "source": "Email-Server"},
        {"timestamp": "2024-01-15 11:15:00", "user": "alice", "action": "file_download", "details": "Downloaded presentation file", "source": "File-Server"},
        {"timestamp": "2024-01-15 12:00:00", "user": "bob", "action": "vpn_connect", "details": "Connected to company VPN", "source": "VPN-Gateway"},
        {"timestamp": "2024-01-15 14:30:00", "user": "charlie", "action": "meeting_join", "details": "Joined team meeting", "source": "Teams"},
        {"timestamp": "2024-01-15 15:45:00", "user": "alice", "action": "file_upload", "details": "Uploaded updated document", "source": "File-Server"},
        {"timestamp": "2024-01-15 16:20:00", "user": "bob", "action": "logout", "details": "Logged out normally", "source": "Local"}
    ]

    suspicious_logs = []

    if scenario in ['mixed', 'exfiltration']:
        # Add USB exfiltration
        suspicious_logs.extend([
            {"timestamp": "2024-01-15 22:30:00", "user": "eve", "action": "file_copy", "details": "Copied 500MB to USB device", "source": "USB-001"},
            {"timestamp": "2024-01-15 23:15:00", "user": "eve", "action": "file_copy", "details": "Copied 2GB of confidential data to external drive", "source": "External-HDD"}
        ])

    if scenario in ['mixed', 'failed_logins']:
        # Add failed login attempts
        for i in range(5):
            suspicious_logs.append({
                "timestamp": f"2024-01-15 17:{30+i:02d}:00",
                "user": "mallory",
                "action": "login_attempt",
                "details": "Failed login attempt",
                "source": "Remote"
            })

    if scenario in ['mixed', 'unusual_behavior']:
        # Add unusual timing activities
        suspicious_logs.extend([
            {"timestamp": "2024-01-15 02:15:00", "user": "trudy", "action": "file_access", "details": "Accessed 50 files rapidly at 2 AM", "source": "Network"},
            {"timestamp": "2024-01-15 23:45:00", "user": "eve", "action": "vpn_transfer", "details": "Large data transfer over VPN at night", "source": "VPN-Server"}
        ])

    # Combine and shuffle logs
    all_logs = base_logs[:count-3] + suspicious_logs[:3]  # Mix normal and suspicious
    random.shuffle(all_logs)

    return all_logs[:count]

def count_detected_alerts(logs):
    """Count how many alerts would be generated from these logs"""
    # Simple simulation of alert detection
    alert_count = 0

    for log in logs:
        details = log.get('details', '').lower()
        action = log.get('action', '')

        # Check for suspicious patterns
        if any(keyword in details for keyword in ['usb', 'external', 'night', 'failed', 'unauthorized', 'rapidly']):
            alert_count += 1
        elif action in ['file_copy'] and any(unit in details for unit in ['gb', 'mb']):
            alert_count += 1

    return min(alert_count, 5)  # Cap at 5 alerts for display

@app.route('/upload', methods=['GET', 'POST'])
def upload_logs():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)

        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # Process the uploaded file
            process_log_file(file_path, filename)

            flash('File successfully uploaded and processed')
            return redirect(url_for('dashboard'))

    return render_template('upload.html')

def process_log_file(file_path, filename):
    """Process uploaded log file (CSV or JSON)"""
    try:
        if filename.endswith('.csv'):
            logs = parse_csv_file(file_path)
        elif filename.endswith('.json'):
            logs = parse_json_file(file_path)
        else:
            raise ValueError("Unsupported file format")

        # Store logs in database
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        for log in logs:
            cursor.execute('''
                INSERT INTO logs (timestamp, user, action, details, source)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                log.get('timestamp'),
                log.get('user'),
                log.get('action'),
                json.dumps(log),
                filename
            ))

        conn.commit()
        conn.close()

        # Analyze logs for suspicious activities
        analyze_logs(logs)

    except Exception as e:
        print(f"Error processing file: {e}")
        flash(f"Error processing file: {str(e)}")

def parse_csv_file(file_path):
    """Parse CSV file manually without pandas"""
    logs = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                # Convert timestamp to ISO format if needed
                timestamp = row.get('timestamp', '')
                if timestamp and not timestamp.endswith('Z'):
                    try:
                        # Try to parse common timestamp formats
                        dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
                        timestamp = dt.isoformat() + 'Z'
                    except:
                        pass  # Keep original format

                logs.append({
                    'timestamp': timestamp,
                    'user': row.get('user', ''),
                    'action': row.get('action', ''),
                    'details': row.get('details', ''),
                    'source': row.get('source', '')
                })
    except Exception as e:
        print(f"Error parsing CSV: {e}")
    return logs

def parse_json_file(file_path):
    """Parse JSON file manually without pandas"""
    logs = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
            if isinstance(data, list):
                for item in data:
                    # Convert timestamp to ISO format if needed
                    timestamp = item.get('timestamp', '')
                    if timestamp and not timestamp.endswith('Z'):
                        try:
                            if 'T' in timestamp:
                                dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                            else:
                                dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
                            timestamp = dt.isoformat() + 'Z'
                        except:
                            pass  # Keep original format

                    logs.append({
                        'timestamp': timestamp,
                        'user': item.get('user', ''),
                        'action': item.get('action', ''),
                        'details': item.get('details', ''),
                        'source': item.get('source', '')
                    })
    except Exception as e:
        print(f"Error parsing JSON: {e}")
    return logs

def analyze_logs(logs):
    """Analyze logs using detection rules"""
    alerts = []

    # Group logs by user for pattern analysis
    user_logs = {}
    for log in logs:
        user = log.get('user', 'unknown')
        if user not in user_logs:
            user_logs[user] = []
        user_logs[user].append(log)

    # Apply detection rules for each user
    for user, user_log_list in user_logs.items():
        alerts.extend(detect_usb_exfiltration(user, user_log_list))
        alerts.extend(detect_vpn_exfiltration(user, user_log_list))
        alerts.extend(detect_failed_logins(user, user_log_list))
        alerts.extend(detect_unusual_behavior(user, user_log_list))
        alerts.extend(detect_custom_rules(user, user_log_list))

    # Store alerts in database
    if alerts:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        for alert in alerts:
            cursor.execute('''
                INSERT INTO alerts (type, user, details, severity, timestamp)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                alert['type'],
                alert['user'],
                alert['details'],
                alert['severity'],
                alert.get('timestamp', datetime.now().isoformat())
            ))

        conn.commit()
        conn.close()

def detect_usb_exfiltration(user, logs):
    """Detect USB data exfiltration attempts"""
    alerts = []
    usb_logs = [log for log in logs if log.get('action') == 'file_copy' and 'usb' in log.get('source', '').lower()]

    for log in usb_logs:
        details = log.get('details', '')
        # Check for large data transfers (>100MB)
        if any(unit in details.lower() for unit in ['gb', 'mb']):
            size_match = re.search(r'(\d+(?:\.\d+)?)\s*(gb|mb)', details.lower())
            if size_match:
                size_value = float(size_match.group(1))
                size_unit = size_match.group(2)

                if size_unit == 'gb' or (size_unit == 'mb' and size_value > 100):
                    alerts.append({
                        'type': 'USB Data Exfiltration',
                        'user': user,
                        'details': f"Large data transfer to USB: {details}",
                        'severity': 'high',
                        'timestamp': log.get('timestamp')
                    })

    return alerts

def detect_vpn_exfiltration(user, logs):
    """Detect VPN data exfiltration attempts"""
    alerts = []
    vpn_logs = [log for log in logs if log.get('action') == 'vpn_transfer' or 'vpn' in log.get('source', '').lower()]

    for log in vpn_logs:
        details = log.get('details', '')
        # Check for large data transfers over VPN (>500MB)
        if any(unit in details.lower() for unit in ['gb', 'mb']):
            size_match = re.search(r'(\d+(?:\.\d+)?)\s*(gb|mb)', details.lower())
            if size_match:
                size_value = float(size_match.group(1))
                size_unit = size_match.group(2)

                if size_unit == 'gb' or (size_unit == 'mb' and size_value > 500):
                    alerts.append({
                        'type': 'VPN Data Exfiltration',
                        'user': user,
                        'details': f"Unusual large data transfer over VPN: {details}",
                        'severity': 'high',
                        'timestamp': log.get('timestamp')
                    })

    return alerts

def detect_failed_logins(user, logs):
    """Detect multiple failed login attempts"""
    alerts = []
    failed_login_logs = [log for log in logs if log.get('action') == 'login_attempt' and 'failed' in log.get('details', '').lower()]

    # Check for consecutive failed attempts (3 or more)
    consecutive_failures = 0
    for log in failed_login_logs:
        if 'failed' in log.get('details', '').lower():
            consecutive_failures += 1
            if consecutive_failures >= 3:
                alerts.append({
                    'type': 'Multiple Failed Logins',
                    'user': user,
                    'details': f"{consecutive_failures} consecutive failed login attempts detected",
                    'severity': 'medium',
                    'timestamp': log.get('timestamp')
                })
        else:
            consecutive_failures = 0

    return alerts

def detect_unusual_behavior(user, logs):
    """Detect unusual user behavior patterns"""
    alerts = []
    current_hour = datetime.now().hour

    # Check for activity outside normal business hours (9 AM - 6 PM)
    unusual_hour_logs = [
        log for log in logs
        if log.get('timestamp') and
        (datetime.fromisoformat(log['timestamp'].replace('Z', '+00:00')).hour < 9 or
         datetime.fromisoformat(log['timestamp'].replace('Z', '+00:00')).hour > 18)
    ]

    if unusual_hour_logs:
        alerts.append({
            'type': 'Unusual Behavior',
            'user': user,
            'details': f"Activity detected outside normal business hours ({len(unusual_hour_logs)} events)",
            'severity': 'low',
            'timestamp': datetime.now().isoformat()
        })

    # Check for unusual file access patterns
    file_access_logs = [log for log in logs if log.get('action') == 'file_access']
    if len(file_access_logs) > 50:  # More than 50 file accesses in a short period
        alerts.append({
            'type': 'Unusual Behavior',
            'user': user,
            'details': f"Unusual file access pattern: {len(file_access_logs)} file accesses detected",
            'severity': 'medium',
            'timestamp': datetime.now().isoformat()
        })

    return alerts

def detect_custom_rules(user, logs):
    """Apply custom detection rules"""
    alerts = []

    # Get enabled custom rules from database
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM rules WHERE enabled = 1')
    rules = cursor.fetchall()
    conn.close()

    for rule in rules:
        rule_id, name, description, condition, severity, enabled = rule

        # Simple condition evaluation (can be extended for more complex logic)
        if evaluate_condition(condition, logs):
            alerts.append({
                'type': name,
                'user': user,
                'details': description,
                'severity': severity,
                'timestamp': datetime.now().isoformat()
            })

    return alerts

def evaluate_condition(condition, logs):
    """Evaluate a custom rule condition"""
    try:
        # Simple keyword-based evaluation
        keywords = condition.lower().split('and')
        for keyword in keywords:
            keyword = keyword.strip()
            found = False
            for log in logs:
                if keyword in log.get('details', '').lower() or keyword in log.get('action', '').lower():
                    found = True
                    break
            if not found:
                return False
        return True
    except:
        return False

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=False, host='0.0.0.0', port=port)
